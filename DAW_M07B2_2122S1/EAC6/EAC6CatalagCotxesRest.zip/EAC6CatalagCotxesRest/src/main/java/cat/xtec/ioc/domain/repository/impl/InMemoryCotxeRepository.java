
package cat.xtec.ioc.domain.repository.impl;


import cat.xtec.ioc.domain.Cotxe;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import org.springframework.stereotype.Repository;

@Repository
public class InMemoryCotxeRepository {
    private static final List<Cotxe> cotxes = new ArrayList<Cotxe>();

    @PostConstruct
    public void initData() {
        Cotxe nissan = new Cotxe();
        nissan.setMarca("nissan");
        nissan.setModel("LEAF");
        nissan.setEstoc(50);
        nissan.setPreu(2000f);
        cotxes.add(nissan);
        
        Cotxe nissan2 = new Cotxe();
        nissan2.setMarca("nissan");
        nissan2.setModel("Micra");
        nissan2.setEstoc(500);
            nissan2.setPreu(25000f);
        cotxes.add(nissan2); 
        
        Cotxe tesla = new Cotxe();
        tesla.setMarca("Tesla");
        tesla.setModel("Model S");
        tesla.setEstoc(200);
        tesla.setPreu(75000f);
        cotxes.add(tesla);        

        Cotxe ford = new Cotxe();
        ford.setMarca("Ford");
        ford.setModel("B-Max");
        ford.setEstoc(300);
        ford.setPreu(30000f);
        cotxes.add(ford); 
        for (Cotxe cotxe : cotxes) {
            System.out.println(cotxe.getMarca()  + cotxe.getModel() + cotxe.getEstoc() + cotxe.getPreu());
        }        
        
    }

/*    
    public String findCoxeByModel(String model) {
        Assert.notNull(model);
        String result = null;
        for (Cotxe cotxe : cotxes) {
            if (model.equals(cotxe.getModel())) {
                result = "El Model es: "+cotxe.getModel() +" La marca es: "+ cotxe.getMarca() + " El estoc es: "+ cotxe.getEstoc()+ " El preu es " + cotxe.getPreu();
            }
        }

        return result;
    }
*/

    public List<Cotxe> findCoxesByModel(String model) {

        
        List<Cotxe> resultats = new ArrayList<Cotxe>();
        
        for (Cotxe cotxe : cotxes) {
           if (cotxe.getModel().equals(model)) {
                resultats.add(cotxe);
            }
        } 
        for (Cotxe cotxe : resultats) {
            System.out.println(cotxe.getMarca()  + cotxe.getModel() + cotxe.getEstoc() + cotxe.getPreu());
        } 
                return resultats;
    }
    
    
    
public List<Cotxe> findCotxesByMarca(String marca) {

        List<Cotxe> resultats = new ArrayList<Cotxe>();

        for (Cotxe cotxe : cotxes) {
            if (cotxe.getMarca().equals(marca)) {
                resultats.add(cotxe);
            }
        }
        //for (Cotxe cotxe : resultats) {
          //  System.out.println(cotxe.getModel() + cotxe.getMarca() + cotxe.getEstoc() + cotxe.getPreu());
        //}
        
        return resultats;

    }

    
public List<Cotxe> obtenirTotsElsCotxes() {

        List<Cotxe> resultats = new ArrayList<Cotxe>();

        for (Cotxe cotxe : cotxes) {
                resultats.add(cotxe);
            //System.out.println(cotxe.getModel() + cotxe.getMarca() + cotxe.getEstoc() + cotxe.getPreu());                
            }
        
        return resultats;

    }    
    
    
}