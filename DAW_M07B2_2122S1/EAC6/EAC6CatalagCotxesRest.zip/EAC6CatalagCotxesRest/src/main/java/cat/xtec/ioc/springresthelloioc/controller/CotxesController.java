package cat.xtec.ioc.springresthelloioc.controller;

import cat.xtec.ioc.domain.Cotxe;
import cat.xtec.ioc.domain.repository.impl.InMemoryCotxeRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CotxesController {

    @Autowired
    private InMemoryCotxeRepository inMemoryCotxeRepository;

    @RequestMapping(method = RequestMethod.GET, value = "/cotxes")
    public List<Cotxe> obtenitTotsElsCotxesController() {
        return inMemoryCotxeRepository.obtenirTotsElsCotxes();
    }

}