/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.xtec.ioc.domain;

     
public class Cotxe {
    private String model;
    private String marca;
    private Integer estoc;
    private Float preu; 

    public Cotxe() {
    }
    


    public Cotxe(String model, String marca, Integer estoc, Float preu) {
        this.model = model;
        this.marca = marca;
        this.estoc = estoc;
        this.preu = preu;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public Integer getEstoc() {
        return estoc;
    }

    public void setEstoc(Integer estoc) {
        this.estoc = estoc;
    }

    public Float getPreu() {
        return preu;
    }

    public void setPreu(Float preu) {
        this.preu = preu;
    }
 
       @Override
    public String toString() {
        return "Cotxe{" + "model=" + model + ", marca=" + marca + ", estoc=" + estoc + ", preu=" + preu + '}';
    }
}
